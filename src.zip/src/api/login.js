const axios = require('axios');

const api = {
  login: '/api/login',
};

export default api;

export function login(parameter) {
  return axios({
    url: api.login,
    method: 'post',
    data: parameter,
  });
}
