<template>
  <div class="ipan_modal-form-cover">
    <div class="ipan_modal-form-container">
      <component :is="currentComponent"></component>
    </div>
  </div>
</template>
<script>
import Login from './login.vue'
export default {
  components: {
    Login
  },
  data () {
    return {
      currentComponent: ''
    }
  },
  created () {
    this.currentComponent = 'Login'
  }
}
</script>
<style scoped>

</style>