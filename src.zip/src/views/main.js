import '../../public/css/layout.css';
import Vue from 'vue';
import main from './login/main.vue';

new Vue({
  data: {
  },
  render: (h) => h(main),
}).$mount('#app');
