const express = require('express');
const fs = require('fs');
const bodyParser = require('body-parser');

const app = express();
app.engine('html', require('express-art-template'));

app.use(express.static('public'));
app.use(express.static('./public/dist'));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.set('views', './public/dist');

const userDataUrl = './public/database/user.json';
app.get('/', (req, res) => {
  fs.readFile(userDataUrl, (err, data) => {
    if (err) {
      res.render('404');
      return;
    }
    res.render('index.html', { users: JSON.parse(data) });
  });
});

app.get('/register', (req, res) => {
  fs.readFile(userDataUrl, (err, data) => {
    if (err) {
      console.log('注册失败');
      return;
    }
    const userArr = JSON.parse(data);
    console.log(data, userArr);
    req.query.date = Date.now();
    console.log(userArr);
    userArr.push(req.query);
    fs.writeFile(userDataUrl, JSON.stringify(userArr), (error) => {
      if (error) {
        console.log('注册失败');
        return;
      }
      res.redirect('/');
    });
  });
});

app.post('/login', (req, res) => {
  console.log(1, req.body);
  res.end('/');
});

// app.get('/public/main.js', (req, res) => {
//     fs.readFile('./public/main.js', (err, data) => {
//         res.send(data.toString())
//     })
// })

app.listen('4000', (err) => {
  if (err) {
    return;
  }
  console.log('server is running');
});
