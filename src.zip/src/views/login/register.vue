<template>
  <div>
    <form action="" class="ipan_modal-form">
      <h1 class="ipan_login-title">注册</h1>
      <input type="text" placeholder="username"/>
      <input type="email" placeholder="email"/>
      <input type="password" placeholder="password"/>
      <a @click="save">register</a>
      <span @click="gotoLogin">login</span>
    </form>
  </div>
</template>
<script>
export default {
  data () {
    return {

    }
  },
  methods: {
    gotoLogin () {
      this.$emit('login')
    }
  }
}
</script>
<style scoped>

</style>