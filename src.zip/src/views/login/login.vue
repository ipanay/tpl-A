<template>
  <div>
    <form class="ipan_modal-form">
      <h1 class="ipan_login-title">登陆</h1>
      <input type="text" v-model="username" placeholder="username">
      <input type="password" v-model="password" placeholder="password">
      <a @click="save">submit</a>
      <span @click="gotoRegister">register?</span>
    </form>
  </div>
</template>
<script>
import{ login } from '../../api/login'
export default {
  data () {
    return {
      username: '',
      password: ''
    }
  },
  methods: {
    gotoRegister () {
      this.$emit('register')
    },
    save () {
      login({ user: this.username, pwd: this.password }).then(res => {
        console.log(9)
      })
    }
  }
}
</script>
<style scoped>

</style>