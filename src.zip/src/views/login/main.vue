<template>
  <div class="ipan_modal-form-cover">
    <div class="ipan_modal-form-container">
      <component
        @register="register"
        @login="login"
        :is="currentComponent"></component>
    </div>
  </div>
</template>
<script>
import Login from './login.vue'
import Register from './register.vue'
export default {
  components: {
    Login,
    Register
  },
  data () {
    return {
      currentComponent: ''
    }
  },
  created () {
    this.currentComponent = 'Login'
  },
  methods: {
    register () {
      this.currentComponent = 'Register'
    },
    login () {
      this.currentComponent = 'Login'
    }
  }
}
</script>
<style scoped>

</style>