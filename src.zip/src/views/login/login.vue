<template>
  <div>
    <form action="" class="ipan_modal-form">
      <h1 class="ipan_login-title">登陆</h1>
      <input type="text" placeholder="username">
      <input type="password" placeholder="password">
      <input type="submit" value="submit"/>
      <span>register?</span>
    </form>
  </div>
</template>
<script>
export default {
    
}
</script>
<style scoped>

</style>